# Image credits

## Real photographs to download

### Shannon Airport exterior
- Author: 瑞丽江的河水
- License: CC BY-SA 4.0
- Commons: https://commons.wikimedia.org/wiki/File:Shannon_Airport_2020-07-12_01.jpg
- Original: https://upload.wikimedia.org/wikipedia/commons/6/6c/Shannon_Airport_2020-07-12_01.jpg
- Intended use: hero
- Any crop/resize/conversion must be disclosed as a modification.

### Limerick Colbert Station
- Author: Sharon Hahn Darlin
- License: CC BY 2.0
- Commons: https://commons.wikimedia.org/wiki/File:Limerick_Colbert_Train_Station.jpg
- Original: https://upload.wikimedia.org/wikipedia/commons/f/ff/Limerick_Colbert_Train_Station.jpg
- Intended use: body image near the arrival/Colbert section.
- Any crop/resize/conversion must be disclosed as a modification.

### Bus Éireann operator example, optional
- Author: AntiRevisionismEnjoyer
- License: CC BY-SA 4.0
- Commons: https://commons.wikimedia.org/wiki/File:Bus_%C3%89ireann_VDL_Futura_Double_Decker.jpg
- Original: https://upload.wikimedia.org/wikipedia/commons/d/d6/Bus_%C3%89ireann_VDL_Futura_Double_Decker.jpg
- IMPORTANT: the photographed vehicle was working Route 115, not Route 343.
- If used, caption it only as a Bus Éireann operator/fleet example. Never imply it is the Shannon Airport to Limerick 343.

## Generated editorial illustrations
The two WebP files in public/images/limerick/shannon-airport-to-limerick/ are generic editorial illustrations created for Path & Roam. They do not depict Shannon Airport, Route 343, Bus Éireann, Kiwitaxi or any real transfer company/location.
