# Path & Roam: Shannon Airport to Limerick asset pack

Place this ZIP in the Path & Roam repository root.

Codex should:
1. Extract the ZIP.
2. Copy/retain the two generated generic WebP illustrations under:
   public/images/limerick/shannon-airport-to-limerick/
3. Download the real photographs listed in source-pack/image-sources.json.
4. Convert new real images to optimized WebP, normally around 1800-2000px maximum dimension, without upscaling.
5. Register all used real images and credits in data/editorial-images.js.
6. Mark generated images as illustrative.
7. Do not use the optional Bus Éireann photo as if it showed Route 343.
8. Do not use the rejected AI webpage mockups from the conversation.
