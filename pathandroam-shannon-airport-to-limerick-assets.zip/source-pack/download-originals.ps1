$ErrorActionPreference = "Stop"

$items = @(
  @{
    Url = "https://upload.wikimedia.org/wikipedia/commons/6/6c/Shannon_Airport_2020-07-12_01.jpg"
    File = "shannon-airport-original.jpg"
  },
  @{
    Url = "https://upload.wikimedia.org/wikipedia/commons/f/ff/Limerick_Colbert_Train_Station.jpg"
    File = "limerick-colbert-station-original.jpg"
  },
  @{
    Url = "https://upload.wikimedia.org/wikipedia/commons/d/d6/Bus_%C3%89ireann_VDL_Futura_Double_Decker.jpg"
    File = "bus-eireann-operator-example-original.jpg"
  }
)

New-Item -ItemType Directory -Force -Path ".\source-pack\downloaded-originals" | Out-Null

foreach ($item in $items) {
  Invoke-WebRequest -Uri $item.Url -OutFile (Join-Path ".\source-pack\downloaded-originals" $item.File)
}
