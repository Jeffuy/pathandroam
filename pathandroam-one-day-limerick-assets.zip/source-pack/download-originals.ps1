param(
  [string]$Destination = "public/images/limerick/one-day-itinerary"
)

New-Item -ItemType Directory -Force -Path $Destination | Out-Null
$data = Get-Content -Raw -Path "./source-pack/image-sources.json" | ConvertFrom-Json
foreach ($item in $data) {
  $outPath = Join-Path $Destination $item.filename_original
  Invoke-WebRequest -Uri $item.original_url -OutFile $outPath
  Write-Host "Downloaded $($item.filename_original)"
}
Write-Host "Now convert the originals to the listed .webp filenames and register attribution."
