# Path & Roam - One Day in Limerick asset pack

This pack contains:
- two ready-to-use AI editorial images in `public/images/limerick/one-day-itinerary/`
- a source pack with verified Wikimedia URLs for recognizable Limerick locations

Important:
This runtime could not download the external Wikimedia binaries directly, so the real landmark photos are provided as exact source URLs in `source-pack/image-sources.json`.
Codex or a local script should download those originals, convert them to WebP using the target filenames, and then place them in:

`public/images/limerick/one-day-itinerary/`

Recommended file usage:
- `nicholas-street-medieval-quarter.webp` -> hero image
- `milk-market-itinerary.webp` -> Saturday start section
- `st-marys-cathedral.webp` -> cathedral section
- `king-johns-castle-itinerary.webp` -> castle section
- `shannon-riverside-walk.webp` -> Shannon walk section
- `traditional-music-session.webp` -> pub / evening section (already included)
- `city-centre-nightlife.webp` -> optional nightlife / late finish section (already included)
